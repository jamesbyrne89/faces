import React, { Component } from 'react';
import './styles.css';

const Profile = () => {
    render() {
        return ( <
            div className = "app-container" >
            <
            /
            div >
        );
    }
}

export default Profile;